package com.src;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

public class FetchDetails {

	public static void main(String[] args) {
		StandardServiceRegistry ssr= new StandardServiceRegistryBuilder().configure("hibernate.config.xml").build();
		Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();
		SessionFactory factory=meta.getSessionFactoryBuilder().build();  //creating SessionFactory
		
		Session s=factory.openSession();  //creating sessions
		Transaction t=s.beginTransaction();  //creating transaction

		System.out.println("Add Employee");
		System.out.println("Delete Employee");
		System.out.println("Update Employee");
		System.out.println("Display Employee");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Choice");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
		{
			Employee e=new Employee();  //inserting into the employee object
			System.out.println("Enter ID ");
			e.setEid(sc.nextInt());
			System.out.println("Enter Name ");
			e.setEname(sc.next());
			System.out.println("Enter Mobile no. ");
			e.setEmob(sc.nextLong());
			System.out.println("Enter DOB ");
			e.setEmpdob(sc.next());
			System.out.println("Enter Salary ");
			e.setEsal(sc.nextInt());
			System.out.println("Enter Gender ");
			e.setGender(sc.next());
			s.save(e);
			System.out.println("Inserted Successfully");
			t.commit();
			break;
			
		}
		case 2:
		{
			System.out.println("Enter the Employee to delete");
			int i=sc.nextInt();
			Query que=s.createQuery("delete from Employee where eid="+i);  //deleting the employee from the table
			int status=que.executeUpdate();
			System.out.println("Deleted Successfully");
			t.commit();
			break;
		}
		case 3:
		{
			Query q=s.createQuery("update Employee set ename=:m,emob=:n,empdob=:o,esal=:p,gender=:r where eid=:id");   //updating the employee from the table
			System.out.println("Enter ID ");
			q.setParameter("id",sc.nextInt());
			System.out.println("Enter Name ");
			q.setParameter("m",sc.next());
			System.out.println("Enter Mobile no. ");
			q.setParameter("n",sc.nextLong());
			System.out.println("Enter DOB ");
			q.setParameter("o",sc.next());
			System.out.println("Enter Salary ");
			q.setParameter("p",sc.nextDouble());
			System.out.println("Enter Gender ");
			q.setParameter("r",sc.next());
			System.out.println("Enter Gender ");
			q.executeUpdate();
			System.out.println("Updated Successfully");
			t.commit();
			break;
		}
		case 4:
		{
		Query que=s.createQuery("from Employee");  
		ArrayList<Employee> list=(ArrayList<Employee>) que.list();
		for(Employee e:list)
		{
			System.out.println(e);  //displaying the values in each rows
		} 
		t.commit();
		break;
		}

	}
	}
}
