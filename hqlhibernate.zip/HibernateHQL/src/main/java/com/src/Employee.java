package com.src;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee1")    //table name
public class Employee
{
	@Id   //primary key
	private int eid;
	private String ename;
	private long emob;
	private String empdob;
	private double esal;
	private String gender;
	public int getEid() {  //getters and setters method
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public long getEmob() {
		return emob;
	}
	public void setEmob(long emob) {
		this.emob = emob;
	}
	public String getEmpdob() {
		return empdob;
	}
	public void setEmpdob(String empdob) {
		this.empdob = empdob;
	}
	public double getEsal() {
		return esal;
	}
	public void setEsal(double esal) {
		this.esal = esal;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", emob=" + emob + ", empdob=" + empdob + ", esal=" + esal
				+ ", gender=" + gender + ", getEid()=" + getEid() + ", getEname()=" + getEname() + ", getEmob()="
				+ getEmob() + ", getEmpdob()=" + getEmpdob() + ", getEsal()=" + getEsal() + ", getGender()="
				+ getGender()+ "]";
	}
	

}
